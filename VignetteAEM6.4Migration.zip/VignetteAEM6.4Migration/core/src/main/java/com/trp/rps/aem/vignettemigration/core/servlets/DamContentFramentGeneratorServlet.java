package com.trp.rps.aem.vignettemigration.core.servlets;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.ValueFormatException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.version.VersionException;
import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.cq.dam.cfm.ContentFragment;
import com.adobe.cq.dam.cfm.ContentFragmentException;
import com.adobe.cq.dam.cfm.ContentFragmentManager;
import com.adobe.cq.dam.cfm.FragmentTemplate;
import com.adobe.granite.asset.api.Asset;
import com.adobe.granite.asset.api.AssetManager;
import com.day.cq.commons.jcr.JcrConstants;
import com.day.cq.dam.api.DamConstants;
import com.google.gson.Gson;

@Component(service = Servlet.class, property = {
		Constants.SERVICE_DESCRIPTION + "= DAM Content Fragment Generator Servlet",
		"sling.servlet.methods=" + HttpConstants.METHOD_GET,
		"sling.servlet.paths=" + "/services/generate/damcontentfragment", "sling.servlet.extensions=" + "json" })
public class DamContentFramentGeneratorServlet extends SlingSafeMethodsServlet {

	private static final String HYPHEN = "-";

	private static final String CFM_MODEL = "/conf/workplace-fdi/settings/dam/cfm/models/cf-fdi-content-model/jcr:content";

	private static final String CONTENT_FRAGMENT_FOLDER_PATH = "/content/dam/workplace-fdi/content-fragments";

	private static final String SLING_FOLDER = "sling:Folder";
	
	private static final String NT_FOLDER = "nt:Folder";

	private static final String QPN_PATH = "path";

	private static final String PN_CONTENT = "content";

	private static final String DAM_ASSET = "dam:Asset";

	private static final String NN_DATA_MASTER = JcrConstants.JCR_CONTENT + "/data/master";

	private static final String SERVICE_ACCOUNT_IDENTIFIER = "cfservice";
	
	private static List<String> cfList;
	
	private static final long serialVersionUID = 1L;

	@Reference
	private ContentFragmentManager fragmentManager;

	@Reference
	ResourceResolverFactory resourceResolverFactory;

	final static Map<String, Object> authInfo = Collections.singletonMap(ResourceResolverFactory.SUBSERVICE,
			(Object) SERVICE_ACCOUNT_IDENTIFIER);

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	protected void doGet(final SlingHttpServletRequest req, final SlingHttpServletResponse resp)
			throws ServletException, IOException {
		cfList = new ArrayList<>();
		String damPath = req.getParameter(QPN_PATH);
		try (ResourceResolver resolver = resourceResolverFactory.getServiceResourceResolver(authInfo)) {
			Session session = resolver.adaptTo(Session.class);
			if (StringUtils.isNotEmpty(damPath)) {
				readHtmlsAndCreateCfs(damPath, resolver, session);
				resp.getWriter().println(new Gson().toJson(cfList));
			} else {
				resp.getWriter().println("Query parameter path has no value!!!");
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e);
		}
	}

	public void readHtmlsAndCreateCfs(String damPath, ResourceResolver resolver, Session session)
			throws RepositoryException, IOException, ContentFragmentException {

		logger.debug("Processing file.... :" + damPath);
		Resource resource = resolver.getResource(damPath);
		Node node = resource.adaptTo(Node.class);
		if (node.isNodeType(NT_FOLDER)) {
			logger.warn("Folder Type should be sling:Folder!, Please use DAM Asset console to create the source folders");
		}
		if (node.isNodeType(SLING_FOLDER)) {
			if (resource.hasChildren()) {
				Iterator<Resource> itrRes = resource.getChildren().iterator();
				while (itrRes.hasNext()) {
					Resource res = itrRes.next();
					readHtmlsAndCreateCfs(res.getPath(), resolver, session);
				}
			} else {
				logger.warn("Empty folder found while crawling:"+ damPath);
			}
		}
		if (node.isNodeType(DAM_ASSET)) {
			Asset asset = resolver.adaptTo(AssetManager.class).getAsset(node.getPath());
			String content = getSourceContent(asset);
			if (StringUtils.isNotEmpty(content)) {
				ContentFragment contentFragment = createContentFragment(resolver, asset);
				setCfValue(content, contentFragment);
				session.save();
				Resource cfRes = contentFragment.adaptTo(Resource.class);
				cfList.add(cfRes.getPath());
			} else {
				logger.warn("Check the source content asset, its empty:" + node.getPath());
			}
		}
	}

	private void setCfValue(String content, ContentFragment contentFragment) throws ValueFormatException,
			VersionException, LockException, ConstraintViolationException, RepositoryException {
		Resource cfRes = contentFragment.adaptTo(Resource.class);
		Resource masterResource = cfRes.getChild(NN_DATA_MASTER);
		Node masterNode = masterResource.adaptTo(Node.class);
		masterNode.setProperty(PN_CONTENT, content);
	}

	private ContentFragment createContentFragment(ResourceResolver resolver, Asset asset)
			throws ContentFragmentException {
		Resource templateResource = resolver.getResource(CFM_MODEL);
		FragmentTemplate fragmentTemplate = templateResource.adaptTo(FragmentTemplate.class);
		Resource parentFolderRes = resolver.getResource(CONTENT_FRAGMENT_FOLDER_PATH);
		String cfName = asset.getName();
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		long index = timestamp.getTime();
		ContentFragment contentFragment = fragmentTemplate.createFragment(parentFolderRes, cfName + HYPHEN + index,
				cfName + HYPHEN + index);
		return contentFragment;
	}

	private String getSourceContent(Asset asset) throws IOException {
		InputStream inputStream = asset.getRendition(DamConstants.ORIGINAL_FILE).getStream();
		if (inputStream != null) {
			return IOUtils.toString(inputStream, StandardCharsets.UTF_8.name());
		} 
		return StringUtils.EMPTY;
	}

	@Activate
	protected void activate(Map<String, Object> props) {
		logger.debug("ContentFragmentGeneratorServlet invoked !!!");
	}
}
