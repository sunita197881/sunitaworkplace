package com.trp.rps.aem.vignettemigration.core.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.engine.EngineConstants;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//	http://localhost:4502/system/console/status-slingfilter
//	http://localhost:4502/content/private/104105/0001.1041050001.html -- This is the old one.
//	http://localhost:4502/content/private/104105/FirstVignetteContent.html
//	http://localhost:4502/content/private/104105/FirstVignetteContent.104105-0001.html
//	http://localhost:4502/content/private/104105/FirstVignetteContent.104105-0002.html

@Component(service = Filter.class, property = {
		Constants.SERVICE_DESCRIPTION + "=Demo to filter incoming plan location requests",
		EngineConstants.SLING_FILTER_SCOPE + "=" + EngineConstants.FILTER_SCOPE_REQUEST,
		Constants.SERVICE_RANKING + ":Integer=-701"

})
public class PlanLocationIDUrlParamsFilter implements Filter {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		/*if (!(request instanceof SlingHttpServletRequest) || !(response instanceof SlingHttpServletResponse)) {
			// Proceed with the rest of the Filter chain
			chain.doFilter(request, response);
			return;
		}*/

		final SlingHttpServletResponse slingResponse = (SlingHttpServletResponse) response;
		final SlingHttpServletRequest slingRequest = (SlingHttpServletRequest) request;
		log.info("request for {}, with selector {}", slingRequest.getRequestPathInfo().getResourcePath(),
				slingRequest.getRequestPathInfo().getSelectorString());
		final Resource resource = slingRequest.getResource();
		log.info("resource is ----------- ====**** " + resource);

		if (resource.getPath().startsWith("/content/private")) {
			String planlocationselector = slingRequest.getRequestPathInfo().getSelectorString();
			log.info("MULTISELECTOR is ----------- ====**** " + planlocationselector);
			slingResponse.setHeader("Content-Type", "text/html");
			if (null != planlocationselector) {
				slingResponse.getWriter().println("<h1>PlanID and LocationID is " + planlocationselector + "</h1>");
			}

		}
		chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// Usually, do nothing
	}

	@Override
	public void destroy() {
		// Usually, do Nothing
	}

}
